package ohjelmistoprojekti1.ticketguru;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TicketguruApplicationTests {

	@Test
	void contextLoads() {
	}

}
