package ohjelmistoprojekti1.ticketguru.domain;

import org.springframework.data.repository.CrudRepository;

public interface LocationRepository extends CrudRepository<Location, Long>{

}
