// package ohjelmistoprojekti1.ticketguru.domain;

// import org.springframework.data.repository.CrudRepository;
// import org.springframework.stereotype.Repository;

// Laitetaan myöhemmin päälle jos käytetään tätä

// @Repository
// public interface PaymentRepository extends CrudRepository<Payment, Long> {
// }
