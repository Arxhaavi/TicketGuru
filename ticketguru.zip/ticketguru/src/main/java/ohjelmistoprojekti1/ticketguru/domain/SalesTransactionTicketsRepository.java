// package ohjelmistoprojekti1.ticketguru.domain;

// import org.springframework.data.repository.CrudRepository;

// public interface SalesTransactionTicketsRepository extends CrudRepository<SalesTransactionTickets, Long> {

// }