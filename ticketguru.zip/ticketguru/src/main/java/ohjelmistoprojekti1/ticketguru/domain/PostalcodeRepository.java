package ohjelmistoprojekti1.ticketguru.domain;

import org.springframework.data.repository.CrudRepository;

public interface PostalcodeRepository extends CrudRepository<Postalcode, String> {

}
