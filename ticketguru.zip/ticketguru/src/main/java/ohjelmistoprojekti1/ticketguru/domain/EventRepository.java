package ohjelmistoprojekti1.ticketguru.domain;

import org.springframework.data.repository.CrudRepository;

public interface EventRepository extends CrudRepository<Event, Long>{

}
